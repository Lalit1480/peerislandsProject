package com.ecommerce.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.inventory.entities.Inventory;
import com.ecommerce.inventory.service.InventoryService;

@RestController
@RequestMapping("/inventory")
public class InventoryController {
	
	@Autowired
	private InventoryService inventoryService;

	@PostMapping("/saveInventory")
	public ResponseEntity<Inventory> addInventory(@RequestBody Inventory inventory){
		Inventory inventory2 = inventoryService.addInventory(inventory);
		
		if(inventory2!=null) {
			return new ResponseEntity<>(inventory2, HttpStatus.CREATED);
		}else {
			return new ResponseEntity<>(inventory2, HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/getAllInventory")
	public ResponseEntity<List<Inventory>> getAllInventory(){
		List<Inventory> inventories = inventoryService.getAllInventory(); 
		return new ResponseEntity<>(inventories, HttpStatus.OK);
	}

	
	@GetMapping("/getInventoryById/{id}")
	public ResponseEntity<Inventory> getInventoryById(@PathVariable String id){
		System.out.println("id  "+id);
		Inventory inventory = inventoryService.getInventoryById(id);
		return new ResponseEntity<>(inventory, HttpStatus.OK);
	}

}
