package com.ecommerce.inventory.service;

import java.util.List;

import com.ecommerce.inventory.entities.Inventory;

public interface InventoryService {

	Inventory addInventory(Inventory inventory);
	List<Inventory> getAllInventory();
	Inventory getInventoryById(String id);
}
