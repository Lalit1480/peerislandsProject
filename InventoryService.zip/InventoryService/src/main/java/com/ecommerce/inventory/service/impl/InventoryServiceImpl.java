package com.ecommerce.inventory.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.inventory.entities.Inventory;
import com.ecommerce.inventory.repository.InventoryRepository;
import com.ecommerce.inventory.service.InventoryService;

@Service
public class InventoryServiceImpl implements InventoryService {
	
	@Autowired
	private InventoryRepository inventoryRepository;

	@Override
	public Inventory addInventory(Inventory inventory) {
		return inventoryRepository.save(inventory);
	}

	@Override
	public List<Inventory> getAllInventory() {
		return inventoryRepository.findAll();
	}

	@Override
	public Inventory getInventoryById(String id) {
		Inventory inventory = inventoryRepository.findById(Long.parseLong(id)).orElseThrow(() -> new RuntimeException("Inventory not found"));
		return inventory;
	}
}
