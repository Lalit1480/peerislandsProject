package com.ecommerce.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.order.entities.Order;
import com.ecommerce.order.service.OrderService;

@RestController
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
	private OrderService service;
	
	@GetMapping("/getOrders")
	public ResponseEntity<?> getOrders(){
		List<Order> orders = service.getOrders();
		return new ResponseEntity<>(orders, HttpStatus.OK);
	}

	@GetMapping("/getOrderById/{id}")
	public ResponseEntity<?> getOrderById(@PathVariable Long id){
		Order order = service.getOrderById(id);
		
		return new ResponseEntity<>(order, HttpStatus.OK);
	}

	@PostMapping("/createOrder")
	public ResponseEntity<?> createOrder(@RequestBody Order order){
		Order order2 = service.createOrder(order);
		if(order.getOrderId()!=null) {
			return new ResponseEntity<Order>(order, HttpStatus.CREATED);	
		}
		else {
			return new ResponseEntity<>("Bad Request", HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping("/deleteOrder/{id}")
	public ResponseEntity<?> deleteOrder(@PathVariable Long id){
		try {
			Order deleteOrder = service.deleteOrder(id);
			return new ResponseEntity<>("Order Deleted", HttpStatus.OK);	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseEntity<>("Bad Request", HttpStatus.BAD_REQUEST);	
		}
		
	}
	
	
	
}
