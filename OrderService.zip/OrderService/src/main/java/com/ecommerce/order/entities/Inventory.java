package com.ecommerce.order.entities;

import lombok.Data;

@Data
public class Inventory {
    private Long productId;
    private Integer quantity;
}