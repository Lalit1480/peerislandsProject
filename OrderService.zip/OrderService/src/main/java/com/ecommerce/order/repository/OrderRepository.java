package com.ecommerce.order.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ecommerce.order.entities.Order;
import com.ecommerce.order.entities.OrderStatus;

public interface OrderRepository extends JpaRepository<Order, Long>{

	@Modifying
    @Query("UPDATE Order o SET o.status = :newStatus WHERE o.status IN :currentStatus")
	void findByStatus(@Param("currentStatus") OrderStatus currentStatus, @Param("newStatus") OrderStatus newStatus);
	
	
    Order findByOrderIdAndStatus(Long id, OrderStatus status);
    
    Optional<Order> findByOrderId(Long orderId);

}
