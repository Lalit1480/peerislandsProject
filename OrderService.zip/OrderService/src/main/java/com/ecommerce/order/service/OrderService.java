package com.ecommerce.order.service;

import java.util.List;

import com.ecommerce.order.entities.Order;

public interface OrderService {

	Order getOrderById(Long id);
	List<Order> getOrders();
	Order createOrder(Order order);
	Order deleteOrder(Long id);
	
}
