package com.ecommerce.order.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.order.entities.Inventory;
import com.ecommerce.order.entities.Order;
import com.ecommerce.order.entities.OrderStatus;
import com.ecommerce.order.repository.OrderRepository;
import com.ecommerce.order.service.InventoryClient;
import com.ecommerce.order.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	private OrderRepository repo;
	
	@Autowired
	private InventoryClient inventoryClient;
	
	@Override
	public Order createOrder(Order order) {
		Order result = null;
		Inventory inventoryDetail = inventoryClient.getInventoryById(order.getProductId());
		
		if( inventoryDetail.getQuantity() < order.getQuantity()) {
			throw new RuntimeException("order quantity is not avaible in stock");
		}
		else if(inventoryDetail != null && inventoryDetail.getQuantity()>0 ) { // && ( inventoryDetail.getQuantity() >= order.getQuantity())
			result = repo.save(order);
		}
		return result;
	}

	@Override
	public Order deleteOrder(Long id) {
//		Order order = repo.findById(id).orElseThrow(() -> new RuntimeException("order id not found"));
		
		Order order = repo.findByOrderIdAndStatus(id, OrderStatus.PENDING);
		order.setStatus(OrderStatus.CANCELLED);
		Order save = repo.save(order);
		return new Order();
	}

	@Override
	public Order getOrderById(Long id) {
		Order order = repo.findByOrderId(id).orElseThrow(() -> new RuntimeException("Order id not found")); 
		return order;
	}

	@Override
	public List<Order> getOrders() {
		return repo.findAll();
	}

	

}
