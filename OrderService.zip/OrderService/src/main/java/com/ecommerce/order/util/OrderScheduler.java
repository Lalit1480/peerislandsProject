package com.ecommerce.order.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.order.entities.OrderStatus;
import com.ecommerce.order.repository.OrderRepository;


@Component
public class OrderScheduler {
	
	@Autowired
	private OrderRepository orderRepository;

	@Transactional
	@Scheduled(fixedRate = 300000)  // 60000 milliseconds = 1 minute
    public void runTask() {
        System.out.println("Task executed at " + java.time.LocalDateTime.now());
        orderRepository.findByStatus(OrderStatus.PENDING, OrderStatus.PROCESSING);
    }
}
