package com.ecommerce.product.entities;

import lombok.Data;

@Data
public class Inventory {
    private Long productId;
    private Integer quantity;
}