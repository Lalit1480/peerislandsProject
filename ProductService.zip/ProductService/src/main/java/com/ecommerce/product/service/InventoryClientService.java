package com.ecommerce.product.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ecommerce.product.entities.Inventory;

@FeignClient(name="inventory-service", url = "http://localhost:8081")
public interface InventoryClientService {

	@GetMapping("/inventory/getInventoryById/{id}")
	public Inventory getInventoryById(@PathVariable Long id);
	
}
