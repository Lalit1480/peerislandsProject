package com.ecommerce.product.service;

import java.util.List;

import com.ecommerce.product.entities.Product;

public interface ProductService {

	Product addProduct(Product product);
	Product getProductById(Long id);
	List<Product> getProducts();
}
