package com.ecommerce.product.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.ecommerce.product.entities.Product;
import com.ecommerce.product.repositories.ProductRepository;
import com.ecommerce.product.service.InventoryClientService;
import com.ecommerce.product.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	
//	@Autowired
	private ProductRepository productRepository;
	
//	@Autowired
	private InventoryClientService inventoryClientService;
	
	
	

	public ProductServiceImpl(ProductRepository productRepository, InventoryClientService inventoryClientService) {
		this.productRepository = productRepository;
		this.inventoryClientService = inventoryClientService;
	}

	@Override
	public Product addProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public Product getProductById(Long id) {
		Product product = productRepository.findById(id).orElseThrow(()-> new RuntimeException("Product Not Found .."));
		System.out.println("sadf   "+inventoryClientService.getInventoryById(id));
		product.setInventory(inventoryClientService.getInventoryById(id));
		return product;
	}

	@Override
	public List<Product> getProducts() {
//		return productRepository.findAll();
		
		List<Product> list = productRepository.findAll();
		List<Product> newList =list.stream().map(e-> {
			e.setInventory(inventoryClientService.getInventoryById(e.getId()));
			return e;
		}).collect(Collectors.toList());
		
		return newList;
	}

}
